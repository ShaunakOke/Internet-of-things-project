from picamera import PiCamera
from time import sleep
from random import randint
camera= PiCamera()
camera.resolution=(2592,1944)
camera.framerate=15
camera.start_preview()
sleep(10)
i=randint(0,1000)
camera.capture('/home/pi/project/image%s.jpg' % i)
camera.stop_preview()
