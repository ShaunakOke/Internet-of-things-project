import way2sms
q=way2sms.sms("7038792582","Q2253R")
q.send(8888333993,"hi")

q.logout()