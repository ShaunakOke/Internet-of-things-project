import time
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BOARD)
GPIO.setup(23, GPIO.IN)
GPIO.setup(11, GPIO.OUT)

while True:
	if(GPIO.input(23) == True):
                GPIO.output(11, 1)
		print "motion detected"
	else:
                GPIO.output(11, 0)
		print "no motion"
	time.sleep(0.5)